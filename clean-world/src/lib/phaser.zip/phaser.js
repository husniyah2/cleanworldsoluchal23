export default window.Phaser
